const API_BASE = '/';
let swotChart = null;

document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('ideaForm');
    const resultsSection = document.getElementById('results-section');
    const toggleTheme = document.getElementById('toggleTheme');
    
    // Theme toggle
    const currentTheme = localStorage.getItem('theme') || 'light';
    document.documentElement.setAttribute('data-theme', currentTheme);
    toggleTheme.textContent = currentTheme === 'dark' ? '☀️' : '🌙';
    
    toggleTheme.addEventListener('click', () => {
        const newTheme = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
        document.documentElement.setAttribute('data-theme', newTheme);
        localStorage.setItem('theme', newTheme);
        toggleTheme.textContent = newTheme === 'dark' ? '☀️' : '🌙';
    });
    
    // Form submit
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const niche = document.getElementById('niche').value;
        const market = document.getElementById('market').value;
        const budget = document.getElementById('budget').value;
        
        try {
            const response = await fetch(API_BASE + 'generate/', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ niche, market, budget })
            });
            
            if (!response.ok) throw new Error('Erro na geração');
            
            const data = await response.json();
            displayResults(data);
            resultsSection.classList.remove('hidden');
            form.reset();
            loadHistory();
        } catch (error) {
            alert('Erro: ' + error.message);
        }
    });
    
    // New idea
    document.getElementById('new-idea').addEventListener('click', () => {
        resultsSection.classList.add('hidden');
    });
    
    loadHistory();
});

function displayResults(data) {
    const ideasList = document.getElementById('ideas-list');
    ideasList.innerHTML = '';
    
    data.ideas.forEach(idea => {
        const card = document.createElement('div');
        card.className = 'idea-card';
        card.innerHTML = `
            <h3>${idea.title}</h3>
            <p>${idea.description}</p>
            <strong>Receita:</strong> ${idea.revenue}<br>
            <strong>Tech:</strong> ${idea.tech}
        `;
        ideasList.appendChild(card);
    });
    
    // SWOT Chart
    const ctx = document.getElementById('swot-chart').innerHTML = `
        <canvas id="swotCanvas" width="400" height="200"></canvas>
        <h4>SWOT Analysis</h4>
        <div id="swot-text">
            <strong>Forças:</strong> ${data.swot.Strengths}<br>
            <strong>Fraquezas:</strong> ${data.swot.Weaknesses}<br>
            <strong>Oportunidades:</strong> ${data.swot.Opportunities}<br>
            <strong>Ameaças:</strong> ${data.swot.Threats}
        </div>
    `;
    
    setTimeout(() => {
        const swotCtx = document.getElementById('swotCanvas')?.getContext('2d');
        if (swotCtx && swotChart) swotChart.destroy();
        
        swotChart = new Chart(swotCtx, {
            type: 'doughnut',
            data: {
                labels: ['Forças', 'Oportunidades', 'Fraquezas', 'Ameaças'],
                datasets: [{
                    data: [30, 25, 20, 25],
                    backgroundColor: ['#28a745', '#007bff', '#dc3545', '#ffc107']
                }]
            },
            options: { responsive: true }
        });
    }, 100);
}

async function loadHistory() {
    try {
        const response = await fetch(API_BASE + 'ideas/');
        const ideas = await response.json();
        const historyList = document.getElementById('history-list');
        historyList.innerHTML = '';
        
        ideas.slice(0, 5).forEach(idea => {
            const item = document.createElement('div');
            item.className = 'history-item';
            item.innerHTML = `
                <strong>${idea.niche} - ${idea.market}</strong><br>
                ${new Date(idea.created_at).toLocaleString('pt-BR')}
            `;
            historyList.appendChild(item);
        });
    } catch (error) {
        console.error('Erro histórico:', error);
    }
}
